===============================================================================
                    AETHER ACCESS - DEPLOYMENT PACKAGE
                           Version: 2.0.0
===============================================================================

Quick Start:
  1. Extract this package: tar -xzf aether-access-2.0.0.tar.gz
  2. Run installer: sudo ./scripts/install.sh
  3. Verify: curl http://localhost:8080/health

For detailed instructions, see: docs/INSTALLATION_GUIDE.md

Directory Contents:
  - api/           API server modules
    - unified_api_server.py      Main API server
    - ambient_export_daemon.py   Ambient.ai event export daemon
  - python/        HAL Python bindings
  - scripts/       Installation scripts
  - config/        Configuration templates
    - aether.env.template        API server config
    - ambient.env.template       Ambient.ai export config
  - systemd/       Service files
    - aether-access.service          API server service
    - aether-ambient-export.service  Ambient.ai export service
  - docs/          Documentation

Ambient.ai Integration:
  To enable Ambient.ai event export:
  1. Copy /etc/aether/ambient.env.template to /etc/aether/ambient.env
  2. Add your AMBIENT_API_KEY
  3. Enable service: sudo systemctl enable aether-ambient-export
  4. Start service: sudo systemctl start aether-ambient-export

Generated: Tue Mar  3 21:23:38 PST 2026
===============================================================================
