===============================================================================
                    AETHER ACCESS - DEPLOYMENT PACKAGE
                           Version: 2.0.0
===============================================================================

Quick Start:
  1. Extract this package: tar -xzf aether-access-2.0.0.tar.gz
  2. Run installer: sudo ./scripts/install.sh
  3. Verify: curl http://localhost:8080/health

For detailed instructions, see: docs/INSTALLATION_GUIDE.md

Directory Contents:
  - api/           API server modules
  - python/        HAL Python bindings
  - scripts/       Installation scripts
  - config/        Configuration templates
  - systemd/       Service files
  - docs/          Documentation

Generated: Tue Mar  3 20:56:00 PST 2026
===============================================================================
