#!/usr/bin/env python3
"""
HAL Python Bindings
===================
Python bindings for the HAL C library using ctypes.

This module provides a Pythonic interface to the HAL C library,
allowing the unified API server to interact with hardware through
the compiled HAL shared library.

When the C library is not available, falls back to a SQLite-based
simulation mode that mimics the HAL behavior for development/testing.

Usage:
    from hal_bindings import HAL

    hal = HAL("/path/to/database.db")
    hal.init()

    # Add a card
    hal.add_card("12345", permission_id=1, holder_name="John Doe")

    # Check access
    result = hal.check_access("12345", door_id=1)

    hal.shutdown()
"""

import ctypes
import ctypes.util
import sqlite3
import os
import time
import json
import logging
from typing import Optional, List, Dict, Any, Tuple
from dataclasses import dataclass, asdict
from enum import IntEnum
from datetime import datetime
from pathlib import Path

logger = logging.getLogger(__name__)


# =============================================================================
# Constants and Enums (matching hal_types.h)
# =============================================================================

class ErrorCode(IntEnum):
    OK = 0
    NODE_OFFLINE = 11
    BAD_PARAMS = 21
    OBJECT_NOT_FOUND = 22
    OUT_OF_MEMORY = 23
    DATABASE = 24
    FAILED = 25
    ALREADY_EXISTS = 26
    CRYPTO_ERROR = 27
    NOT_ENABLED = 28
    INVALID_STATE = 29
    AUTH_FAILED = 30


class AccessDecision(IntEnum):
    GRANT = 0
    DENY = 1
    ERROR = 2


class DenyReason(IntEnum):
    CARD_NOT_FOUND = 0
    NO_PERMISSION = 1
    TIME_RESTRICTION = 2
    CARD_BLOCKED = 3
    DOOR_NOT_FOUND = 4
    EXPIRED = 5
    NOT_YET_ACTIVE = 6


class EventType(IntEnum):
    ACCESS_GRANT = 0
    ACCESS_DENY = 1
    DOOR_UNLOCK = 2
    ACCESS_POINT = 3
    INPUT = 4
    READER = 5
    RELAY = 6
    SYSTEM = 7
    EMERGENCY = 8


# =============================================================================
# Data Classes
# =============================================================================

@dataclass
class Card:
    card_number: str
    permission_id: int
    facility_code: int = 0
    holder_name: str = ""
    activation_date: int = 0
    expiration_date: int = 0
    is_active: bool = True
    is_blocked: bool = False
    use_limit: int = 0
    use_count: int = 0
    pin: str = ""
    created_at: int = 0
    updated_at: int = 0


@dataclass
class AccessLevel:
    permission_id: int
    name: str
    description: str = ""
    doors: List[int] = None
    timezones: List[int] = None
    is_active: bool = True

    def __post_init__(self):
        if self.doors is None:
            self.doors = []
        if self.timezones is None:
            self.timezones = []


@dataclass
class Door:
    door_id: int
    name: str
    reader_id: int = 0
    relay_id: int = 0
    strike_time_ms: int = 3000
    held_open_time_s: int = 30
    rex_enabled: bool = True
    osdp_enabled: bool = False
    is_active: bool = True


@dataclass
class Event:
    event_id: str
    event_type: int
    timestamp: int
    card_number: str = ""
    door_id: int = 0
    reader_id: int = 0
    decision: int = 0
    deny_reason: int = 0
    details: str = ""


@dataclass
class AccessResult:
    granted: bool
    reason: str
    decision: AccessDecision
    deny_reason: Optional[DenyReason] = None
    strike_time_ms: int = 3000
    relay_id: int = 0


# =============================================================================
# HAL C Library Bindings (ctypes)
# =============================================================================

class HALCBindings:
    """Direct ctypes bindings to HAL C library"""

    def __init__(self, lib_path: str = None):
        self._lib = None
        self._hal = None

        if lib_path is None:
            # Try to find the library
            lib_path = self._find_library()

        if lib_path and os.path.exists(lib_path):
            try:
                self._lib = ctypes.CDLL(lib_path)
                self._setup_bindings()
                logger.info(f"Loaded HAL C library from {lib_path}")
            except OSError as e:
                logger.warning(f"Failed to load HAL C library: {e}")
                self._lib = None
        else:
            logger.info("HAL C library not found, will use simulation mode")

    def _find_library(self) -> Optional[str]:
        """Find the HAL shared library"""
        # Search paths
        search_paths = [
            "./lib/libhal.so",
            "./lib/libhal.dylib",
            "../lib/libhal.so",
            "../lib/libhal.dylib",
            "/usr/local/lib/libhal.so",
            "/usr/local/lib/libhal.dylib",
        ]

        # Add path relative to this file
        base_dir = Path(__file__).parent.parent
        search_paths.extend([
            str(base_dir / "lib" / "libhal.so"),
            str(base_dir / "lib" / "libhal.dylib"),
            str(base_dir / "build" / "libhal.so"),
            str(base_dir / "build" / "libhal.dylib"),
        ])

        for path in search_paths:
            if os.path.exists(path):
                return path

        # Try system library path
        lib_name = ctypes.util.find_library("hal")
        if lib_name:
            return lib_name

        return None

    def _setup_bindings(self):
        """Setup ctypes function signatures"""
        if not self._lib:
            return

        # HAL_Create
        self._lib.HAL_Create.argtypes = [ctypes.c_void_p]
        self._lib.HAL_Create.restype = ctypes.c_void_p

        # HAL_Destroy
        self._lib.HAL_Destroy.argtypes = [ctypes.c_void_p]
        self._lib.HAL_Destroy.restype = None

        # HAL_Connect
        self._lib.HAL_Connect.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_uint16]
        self._lib.HAL_Connect.restype = ctypes.c_int

        # HAL_Disconnect
        self._lib.HAL_Disconnect.argtypes = [ctypes.c_void_p]
        self._lib.HAL_Disconnect.restype = ctypes.c_int

        # HAL_IsConnected
        self._lib.HAL_IsConnected.argtypes = [ctypes.c_void_p]
        self._lib.HAL_IsConnected.restype = ctypes.c_uint8

        # Add more bindings as needed...

    @property
    def is_available(self) -> bool:
        return self._lib is not None


# =============================================================================
# HAL Simulation (SQLite-based)
# =============================================================================

class HALSimulation:
    """
    SQLite-based HAL simulation for development/testing.
    Mimics the behavior of the real HAL C library.
    """

    def __init__(self, db_path: str = ":memory:"):
        self.db_path = db_path
        self._conn: Optional[sqlite3.Connection] = None
        self._initialized = False
        self._event_counter = 0

    def init(self) -> bool:
        """Initialize the HAL simulation"""
        try:
            self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
            self._conn.row_factory = sqlite3.Row
            self._create_tables()
            self._initialized = True
            logger.info(f"HAL Simulation initialized with database: {self.db_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to initialize HAL simulation: {e}")
            return False

    def shutdown(self):
        """Shutdown the HAL simulation"""
        if self._conn:
            self._conn.close()
            self._conn = None
        self._initialized = False
        logger.info("HAL Simulation shutdown")

    def _create_tables(self):
        """Create database tables"""
        cursor = self._conn.cursor()

        # Cards table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS cards (
                card_number TEXT PRIMARY KEY,
                permission_id INTEGER NOT NULL,
                facility_code INTEGER DEFAULT 0,
                holder_name TEXT DEFAULT '',
                activation_date INTEGER DEFAULT 0,
                expiration_date INTEGER DEFAULT 0,
                is_active INTEGER DEFAULT 1,
                is_blocked INTEGER DEFAULT 0,
                use_limit INTEGER DEFAULT 0,
                use_count INTEGER DEFAULT 0,
                pin TEXT DEFAULT '',
                created_at INTEGER DEFAULT 0,
                updated_at INTEGER DEFAULT 0
            )
        """)

        # Access levels (permissions)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS access_levels (
                permission_id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                description TEXT DEFAULT '',
                doors TEXT DEFAULT '[]',
                timezones TEXT DEFAULT '[]',
                is_active INTEGER DEFAULT 1
            )
        """)

        # Doors
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS doors (
                door_id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                reader_id INTEGER DEFAULT 0,
                relay_id INTEGER DEFAULT 0,
                strike_time_ms INTEGER DEFAULT 3000,
                held_open_time_s INTEGER DEFAULT 30,
                rex_enabled INTEGER DEFAULT 1,
                osdp_enabled INTEGER DEFAULT 0,
                is_active INTEGER DEFAULT 1
            )
        """)

        # Timezones
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS timezones (
                timezone_id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                intervals TEXT DEFAULT '[]',
                is_active INTEGER DEFAULT 1
            )
        """)

        # Events
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS events (
                event_id TEXT PRIMARY KEY,
                event_type INTEGER NOT NULL,
                timestamp INTEGER NOT NULL,
                card_number TEXT DEFAULT '',
                door_id INTEGER DEFAULT 0,
                reader_id INTEGER DEFAULT 0,
                decision INTEGER DEFAULT 0,
                deny_reason INTEGER DEFAULT 0,
                details TEXT DEFAULT '',
                acknowledged INTEGER DEFAULT 0
            )
        """)

        # Holidays
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS holidays (
                holiday_id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                date TEXT NOT NULL,
                recurring INTEGER DEFAULT 0
            )
        """)

        self._conn.commit()

    # -------------------------------------------------------------------------
    # Card Operations
    # -------------------------------------------------------------------------

    def add_card(self, card_number: str, permission_id: int, **kwargs) -> bool:
        """Add a card to the database"""
        try:
            now = int(time.time())
            cursor = self._conn.cursor()
            cursor.execute("""
                INSERT INTO cards (
                    card_number, permission_id, facility_code, holder_name,
                    activation_date, expiration_date, is_active, is_blocked,
                    use_limit, use_count, pin, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                card_number,
                permission_id,
                kwargs.get('facility_code', 0),
                kwargs.get('holder_name', ''),
                kwargs.get('activation_date', 0),
                kwargs.get('expiration_date', 0),
                1 if kwargs.get('is_active', True) else 0,
                1 if kwargs.get('is_blocked', False) else 0,
                kwargs.get('use_limit', 0),
                kwargs.get('use_count', 0),
                kwargs.get('pin', ''),
                now,
                now
            ))
            self._conn.commit()
            return True
        except sqlite3.IntegrityError:
            logger.warning(f"Card {card_number} already exists")
            return False
        except Exception as e:
            logger.error(f"Failed to add card: {e}")
            return False

    def get_card(self, card_number: str) -> Optional[Dict]:
        """Get a card from the database"""
        cursor = self._conn.cursor()
        cursor.execute("SELECT * FROM cards WHERE card_number = ?", (card_number,))
        row = cursor.fetchone()
        if row:
            return dict(row)
        return None

    def get_all_cards(self, limit: int = 100, offset: int = 0) -> List[Dict]:
        """Get all cards from the database"""
        cursor = self._conn.cursor()
        cursor.execute(
            "SELECT * FROM cards ORDER BY created_at DESC LIMIT ? OFFSET ?",
            (limit, offset)
        )
        return [dict(row) for row in cursor.fetchall()]

    def update_card(self, card_number: str, **kwargs) -> bool:
        """Update a card in the database"""
        try:
            updates = []
            values = []
            for key, value in kwargs.items():
                if key in ['permission_id', 'facility_code', 'holder_name',
                          'activation_date', 'expiration_date', 'is_active',
                          'is_blocked', 'use_limit', 'pin']:
                    updates.append(f"{key} = ?")
                    values.append(value)

            if not updates:
                return False

            updates.append("updated_at = ?")
            values.append(int(time.time()))
            values.append(card_number)

            cursor = self._conn.cursor()
            cursor.execute(
                f"UPDATE cards SET {', '.join(updates)} WHERE card_number = ?",
                values
            )
            self._conn.commit()
            return cursor.rowcount > 0
        except Exception as e:
            logger.error(f"Failed to update card: {e}")
            return False

    def delete_card(self, card_number: str) -> bool:
        """Delete a card from the database"""
        try:
            cursor = self._conn.cursor()
            cursor.execute("DELETE FROM cards WHERE card_number = ?", (card_number,))
            self._conn.commit()
            return cursor.rowcount > 0
        except Exception as e:
            logger.error(f"Failed to delete card: {e}")
            return False

    def count_cards(self) -> int:
        """Count total cards"""
        cursor = self._conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM cards")
        return cursor.fetchone()[0]

    # -------------------------------------------------------------------------
    # Access Level Operations
    # -------------------------------------------------------------------------

    def add_access_level(self, permission_id: int, name: str, **kwargs) -> bool:
        """Add an access level"""
        try:
            cursor = self._conn.cursor()
            cursor.execute("""
                INSERT INTO access_levels (permission_id, name, description, doors, timezones, is_active)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                permission_id,
                name,
                kwargs.get('description', ''),
                json.dumps(kwargs.get('doors', [])),
                json.dumps(kwargs.get('timezones', [])),
                1 if kwargs.get('is_active', True) else 0
            ))
            self._conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False
        except Exception as e:
            logger.error(f"Failed to add access level: {e}")
            return False

    def get_access_level(self, permission_id: int) -> Optional[Dict]:
        """Get an access level"""
        cursor = self._conn.cursor()
        cursor.execute("SELECT * FROM access_levels WHERE permission_id = ?", (permission_id,))
        row = cursor.fetchone()
        if row:
            result = dict(row)
            result['doors'] = json.loads(result.get('doors', '[]'))
            result['timezones'] = json.loads(result.get('timezones', '[]'))
            return result
        return None

    def get_all_access_levels(self) -> List[Dict]:
        """Get all access levels"""
        cursor = self._conn.cursor()
        cursor.execute("SELECT * FROM access_levels ORDER BY permission_id")
        results = []
        for row in cursor.fetchall():
            result = dict(row)
            result['doors'] = json.loads(result.get('doors', '[]'))
            result['timezones'] = json.loads(result.get('timezones', '[]'))
            results.append(result)
        return results

    def delete_access_level(self, permission_id: int) -> bool:
        """Delete an access level"""
        try:
            cursor = self._conn.cursor()
            cursor.execute("DELETE FROM access_levels WHERE permission_id = ?", (permission_id,))
            self._conn.commit()
            return cursor.rowcount > 0
        except Exception as e:
            logger.error(f"Failed to delete access level: {e}")
            return False

    # -------------------------------------------------------------------------
    # Door Operations
    # -------------------------------------------------------------------------

    def add_door(self, door_id: int, name: str, **kwargs) -> bool:
        """Add a door"""
        try:
            cursor = self._conn.cursor()
            cursor.execute("""
                INSERT INTO doors (door_id, name, reader_id, relay_id, strike_time_ms,
                                   held_open_time_s, rex_enabled, osdp_enabled, is_active)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                door_id,
                name,
                kwargs.get('reader_id', door_id),
                kwargs.get('relay_id', door_id),
                kwargs.get('strike_time_ms', 3000),
                kwargs.get('held_open_time_s', 30),
                1 if kwargs.get('rex_enabled', True) else 0,
                1 if kwargs.get('osdp_enabled', False) else 0,
                1 if kwargs.get('is_active', True) else 0
            ))
            self._conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False
        except Exception as e:
            logger.error(f"Failed to add door: {e}")
            return False

    def get_door(self, door_id: int) -> Optional[Dict]:
        """Get a door"""
        cursor = self._conn.cursor()
        cursor.execute("SELECT * FROM doors WHERE door_id = ?", (door_id,))
        row = cursor.fetchone()
        if row:
            return dict(row)
        return None

    def get_all_doors(self) -> List[Dict]:
        """Get all doors"""
        cursor = self._conn.cursor()
        cursor.execute("SELECT * FROM doors ORDER BY door_id")
        return [dict(row) for row in cursor.fetchall()]

    def delete_door(self, door_id: int) -> bool:
        """Delete a door"""
        try:
            cursor = self._conn.cursor()
            cursor.execute("DELETE FROM doors WHERE door_id = ?", (door_id,))
            self._conn.commit()
            return cursor.rowcount > 0
        except Exception as e:
            logger.error(f"Failed to delete door: {e}")
            return False

    # -------------------------------------------------------------------------
    # Access Decision
    # -------------------------------------------------------------------------

    def check_access(self, card_number: str, door_id: int) -> Dict:
        """
        Check if a card has access to a door.
        Returns access decision with reason.
        """
        now = int(time.time())

        # Get card
        card = self.get_card(card_number)
        if not card:
            return {
                "granted": False,
                "reason": "CARD_NOT_FOUND",
                "decision": AccessDecision.DENY,
                "deny_reason": DenyReason.CARD_NOT_FOUND
            }

        # Check if card is blocked
        if card.get('is_blocked'):
            return {
                "granted": False,
                "reason": "CARD_BLOCKED",
                "decision": AccessDecision.DENY,
                "deny_reason": DenyReason.CARD_BLOCKED
            }

        # Check if card is active
        if not card.get('is_active'):
            return {
                "granted": False,
                "reason": "CARD_INACTIVE",
                "decision": AccessDecision.DENY,
                "deny_reason": DenyReason.CARD_BLOCKED
            }

        # Check activation date
        activation = card.get('activation_date', 0)
        if activation > 0 and now < activation:
            return {
                "granted": False,
                "reason": "NOT_YET_ACTIVE",
                "decision": AccessDecision.DENY,
                "deny_reason": DenyReason.NOT_YET_ACTIVE
            }

        # Check expiration date
        expiration = card.get('expiration_date', 0)
        if expiration > 0 and now > expiration:
            return {
                "granted": False,
                "reason": "EXPIRED",
                "decision": AccessDecision.DENY,
                "deny_reason": DenyReason.EXPIRED
            }

        # Get door
        door = self.get_door(door_id)
        if not door:
            return {
                "granted": False,
                "reason": "DOOR_NOT_FOUND",
                "decision": AccessDecision.DENY,
                "deny_reason": DenyReason.DOOR_NOT_FOUND
            }

        # Get access level
        permission_id = card.get('permission_id', 0)
        access_level = self.get_access_level(permission_id)
        if not access_level:
            return {
                "granted": False,
                "reason": "NO_PERMISSION",
                "decision": AccessDecision.DENY,
                "deny_reason": DenyReason.NO_PERMISSION
            }

        # Check if door is in access level's door list
        allowed_doors = access_level.get('doors', [])
        if allowed_doors and door_id not in allowed_doors:
            return {
                "granted": False,
                "reason": "NO_PERMISSION_FOR_DOOR",
                "decision": AccessDecision.DENY,
                "deny_reason": DenyReason.NO_PERMISSION
            }

        # TODO: Check timezone restrictions

        # Access granted!
        return {
            "granted": True,
            "reason": "ACCESS_GRANTED",
            "decision": AccessDecision.GRANT,
            "strike_time_ms": door.get('strike_time_ms', 3000),
            "relay_id": door.get('relay_id', door_id)
        }

    # -------------------------------------------------------------------------
    # Event Operations
    # -------------------------------------------------------------------------

    def add_event(self, event_type: int, **kwargs) -> str:
        """Add an event to the buffer"""
        try:
            self._event_counter += 1
            event_id = f"EVT-{int(time.time())}-{self._event_counter:06d}"

            cursor = self._conn.cursor()
            cursor.execute("""
                INSERT INTO events (event_id, event_type, timestamp, card_number,
                                    door_id, reader_id, decision, deny_reason, details)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                event_id,
                event_type,
                int(time.time()),
                kwargs.get('card_number', ''),
                kwargs.get('door_id', 0),
                kwargs.get('reader_id', 0),
                kwargs.get('decision', 0),
                kwargs.get('deny_reason', 0),
                kwargs.get('details', '')
            ))
            self._conn.commit()
            return event_id
        except Exception as e:
            logger.error(f"Failed to add event: {e}")
            return ""

    def get_events(self, limit: int = 100, offset: int = 0,
                   event_type: int = None, acknowledged: bool = None) -> List[Dict]:
        """Get events from the buffer"""
        query = "SELECT * FROM events"
        conditions = []
        params = []

        if event_type is not None:
            conditions.append("event_type = ?")
            params.append(event_type)

        if acknowledged is not None:
            conditions.append("acknowledged = ?")
            params.append(1 if acknowledged else 0)

        if conditions:
            query += " WHERE " + " AND ".join(conditions)

        query += " ORDER BY timestamp DESC LIMIT ? OFFSET ?"
        params.extend([limit, offset])

        cursor = self._conn.cursor()
        cursor.execute(query, params)
        return [dict(row) for row in cursor.fetchall()]

    def acknowledge_event(self, event_id: str) -> bool:
        """Acknowledge an event"""
        try:
            cursor = self._conn.cursor()
            cursor.execute(
                "UPDATE events SET acknowledged = 1 WHERE event_id = ?",
                (event_id,)
            )
            self._conn.commit()
            return cursor.rowcount > 0
        except Exception as e:
            logger.error(f"Failed to acknowledge event: {e}")
            return False

    def count_events(self, acknowledged: bool = None) -> int:
        """Count events"""
        query = "SELECT COUNT(*) FROM events"
        params = []

        if acknowledged is not None:
            query += " WHERE acknowledged = ?"
            params.append(1 if acknowledged else 0)

        cursor = self._conn.cursor()
        cursor.execute(query, params)
        return cursor.fetchone()[0]

    # -------------------------------------------------------------------------
    # Timezone Operations
    # -------------------------------------------------------------------------

    def add_timezone(self, timezone_id: int, name: str, **kwargs) -> bool:
        """Add a timezone"""
        try:
            cursor = self._conn.cursor()
            cursor.execute("""
                INSERT INTO timezones (timezone_id, name, intervals, is_active)
                VALUES (?, ?, ?, ?)
            """, (
                timezone_id,
                name,
                json.dumps(kwargs.get('intervals', [])),
                1 if kwargs.get('is_active', True) else 0
            ))
            self._conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False
        except Exception as e:
            logger.error(f"Failed to add timezone: {e}")
            return False

    def get_all_timezones(self) -> List[Dict]:
        """Get all timezones"""
        cursor = self._conn.cursor()
        cursor.execute("SELECT * FROM timezones ORDER BY timezone_id")
        results = []
        for row in cursor.fetchall():
            result = dict(row)
            result['intervals'] = json.loads(result.get('intervals', '[]'))
            results.append(result)
        return results

    # -------------------------------------------------------------------------
    # Holiday Operations
    # -------------------------------------------------------------------------

    def add_holiday(self, name: str, date: str, recurring: bool = False) -> bool:
        """Add a holiday"""
        try:
            cursor = self._conn.cursor()
            cursor.execute("""
                INSERT INTO holidays (name, date, recurring)
                VALUES (?, ?, ?)
            """, (name, date, 1 if recurring else 0))
            self._conn.commit()
            return True
        except Exception as e:
            logger.error(f"Failed to add holiday: {e}")
            return False

    def get_all_holidays(self) -> List[Dict]:
        """Get all holidays"""
        cursor = self._conn.cursor()
        cursor.execute("SELECT * FROM holidays ORDER BY date")
        return [dict(row) for row in cursor.fetchall()]

    # -------------------------------------------------------------------------
    # Statistics and Health
    # -------------------------------------------------------------------------

    def get_stats(self) -> Dict:
        """Get HAL statistics"""
        return {
            "cards": {
                "total": self.count_cards(),
                "active": self._count_active_cards()
            },
            "events": {
                "total": self.count_events(),
                "pending": self.count_events(acknowledged=False)
            },
            "doors": {
                "total": len(self.get_all_doors())
            },
            "access_levels": {
                "total": len(self.get_all_access_levels())
            }
        }

    def _count_active_cards(self) -> int:
        """Count active cards"""
        cursor = self._conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM cards WHERE is_active = 1 AND is_blocked = 0")
        return cursor.fetchone()[0]

    def get_health(self) -> Dict:
        """Get HAL health status"""
        return {
            "status": "healthy" if self._initialized else "not_initialized",
            "version": "2.0.0",
            "mode": "simulation",
            "database": {
                "connected": self._conn is not None,
                "path": self.db_path
            },
            "uptime_seconds": 0  # Would need to track start time
        }

    def get_diagnostics(self) -> Dict:
        """Get diagnostics information"""
        return {
            "database_path": self.db_path,
            "initialized": self._initialized,
            "event_counter": self._event_counter,
            "cards_count": self.count_cards(),
            "events_count": self.count_events(),
            "doors_count": len(self.get_all_doors()),
            "access_levels_count": len(self.get_all_access_levels()),
            "errors_24h": 0,
            "uptime_seconds": 0
        }


# =============================================================================
# Main HAL Class
# =============================================================================

class HAL:
    """
    Main HAL class that wraps either the C library or simulation.

    This is the primary interface for the unified API server.
    """

    def __init__(self, db_path: str = "hal_database.db"):
        self.db_path = db_path
        self._c_bindings = HALCBindings()
        self._simulation = HALSimulation(db_path)
        self._use_c_library = self._c_bindings.is_available
        self._initialized = False

    def init(self) -> bool:
        """Initialize HAL"""
        if self._use_c_library:
            # TODO: Initialize C library
            logger.info("Using HAL C library")
            self._initialized = True
            return True
        else:
            # Use simulation
            logger.info("Using HAL simulation mode")
            result = self._simulation.init()
            self._initialized = result
            return result

    def shutdown(self):
        """Shutdown HAL"""
        if self._use_c_library:
            # TODO: Shutdown C library
            pass
        else:
            self._simulation.shutdown()
        self._initialized = False

    @property
    def is_initialized(self) -> bool:
        return self._initialized

    @property
    def is_native(self) -> bool:
        return self._use_c_library

    # -------------------------------------------------------------------------
    # Card Operations
    # -------------------------------------------------------------------------

    def add_card(self, card_number: str, permission_id: int, **kwargs) -> bool:
        if self._use_c_library:
            # TODO: Call C library
            pass
        return self._simulation.add_card(card_number, permission_id, **kwargs)

    def get_card(self, card_number: str) -> Optional[Dict]:
        if self._use_c_library:
            # TODO: Call C library
            pass
        return self._simulation.get_card(card_number)

    def get_all_cards(self, limit: int = 100, offset: int = 0) -> List[Dict]:
        if self._use_c_library:
            # TODO: Call C library
            pass
        return self._simulation.get_all_cards(limit, offset)

    def update_card(self, card_number: str, **kwargs) -> bool:
        if self._use_c_library:
            # TODO: Call C library
            pass
        return self._simulation.update_card(card_number, **kwargs)

    def delete_card(self, card_number: str) -> bool:
        if self._use_c_library:
            # TODO: Call C library
            pass
        return self._simulation.delete_card(card_number)

    # -------------------------------------------------------------------------
    # Access Level Operations
    # -------------------------------------------------------------------------

    def add_access_level(self, permission_id: int, name: str, **kwargs) -> bool:
        return self._simulation.add_access_level(permission_id, name, **kwargs)

    def get_access_level(self, permission_id: int) -> Optional[Dict]:
        return self._simulation.get_access_level(permission_id)

    def get_all_access_levels(self) -> List[Dict]:
        return self._simulation.get_all_access_levels()

    def delete_access_level(self, permission_id: int) -> bool:
        return self._simulation.delete_access_level(permission_id)

    # -------------------------------------------------------------------------
    # Door Operations
    # -------------------------------------------------------------------------

    def add_door(self, door_id: int, name: str, **kwargs) -> bool:
        return self._simulation.add_door(door_id, name, **kwargs)

    def get_door(self, door_id: int) -> Optional[Dict]:
        return self._simulation.get_door(door_id)

    def get_all_doors(self) -> List[Dict]:
        return self._simulation.get_all_doors()

    def delete_door(self, door_id: int) -> bool:
        return self._simulation.delete_door(door_id)

    # -------------------------------------------------------------------------
    # Access Decision
    # -------------------------------------------------------------------------

    def check_access(self, card_number: str, door_id: int) -> Dict:
        if self._use_c_library:
            # TODO: Call C library HAL_DecideAccess
            pass
        return self._simulation.check_access(card_number, door_id)

    # -------------------------------------------------------------------------
    # Event Operations
    # -------------------------------------------------------------------------

    def add_event(self, event_type: int, **kwargs) -> str:
        return self._simulation.add_event(event_type, **kwargs)

    def get_events(self, limit: int = 100, offset: int = 0, **kwargs) -> List[Dict]:
        return self._simulation.get_events(limit, offset, **kwargs)

    def acknowledge_event(self, event_id: str) -> bool:
        return self._simulation.acknowledge_event(event_id)

    # -------------------------------------------------------------------------
    # Timezone Operations
    # -------------------------------------------------------------------------

    def add_timezone(self, timezone_id: int, name: str, **kwargs) -> bool:
        return self._simulation.add_timezone(timezone_id, name, **kwargs)

    def get_all_timezones(self) -> List[Dict]:
        return self._simulation.get_all_timezones()

    # -------------------------------------------------------------------------
    # Holiday Operations
    # -------------------------------------------------------------------------

    def add_holiday(self, name: str, date: str, recurring: bool = False) -> bool:
        return self._simulation.add_holiday(name, date, recurring)

    def get_all_holidays(self) -> List[Dict]:
        return self._simulation.get_all_holidays()

    # -------------------------------------------------------------------------
    # Statistics and Health
    # -------------------------------------------------------------------------

    def get_stats(self) -> Dict:
        return self._simulation.get_stats()

    def get_health(self) -> Dict:
        health = self._simulation.get_health()
        health['mode'] = 'native' if self._use_c_library else 'simulation'
        return health

    def get_diagnostics(self) -> Dict:
        return self._simulation.get_diagnostics()


# =============================================================================
# Module-level convenience
# =============================================================================

# Default instance
_default_hal: Optional[HAL] = None


def get_hal(db_path: str = "hal_database.db") -> HAL:
    """Get or create the default HAL instance"""
    global _default_hal
    if _default_hal is None:
        _default_hal = HAL(db_path)
    return _default_hal


# =============================================================================
# Main (for testing)
# =============================================================================

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)

    print("HAL Python Bindings Test")
    print("=" * 50)

    hal = HAL(":memory:")
    print(f"Initialized: {hal.init()}")
    print(f"Mode: {'Native' if hal.is_native else 'Simulation'}")

    # Add test data
    print("\nAdding test data...")
    hal.add_door(1, "Main Entrance")
    hal.add_door(2, "Back Door")
    hal.add_access_level(1, "Full Access", doors=[1, 2])
    hal.add_access_level(2, "Limited", doors=[1])
    hal.add_card("12345", 1, holder_name="John Doe")
    hal.add_card("67890", 2, holder_name="Jane Smith")

    # Test access
    print("\nTesting access decisions...")
    result = hal.check_access("12345", 1)
    print(f"Card 12345 -> Door 1: {result}")

    result = hal.check_access("67890", 2)
    print(f"Card 67890 -> Door 2: {result}")

    result = hal.check_access("99999", 1)
    print(f"Card 99999 -> Door 1: {result}")

    # Stats
    print("\nStatistics:")
    print(hal.get_stats())

    # Health
    print("\nHealth:")
    print(hal.get_health())

    hal.shutdown()
    print("\nDone!")
