===============================================================================
                        AETHER HAL - DEPLOYMENT PACKAGE
              Hardware Abstraction Layer for Azure BLU-IC2 Controllers
                               Version: 2.0.0
===============================================================================

Quick Start:
  1. Extract: tar -xzf aether-hal-2.0.0.tar.gz
  2. Install: sudo ./scripts/install.sh
  3. Verify:  curl http://localhost:8080/health

For detailed instructions, see: docs/INSTALLATION_GUIDE.md

API Documentation: http://<panel-ip>:8080/docs

Features:
  - Event-driven architecture with 100K event buffer
  - Local SQLite card database with 1M+ capacity
  - OSDP/Wiegand/DESFire protocol support
  - Ambient.ai event export integration
  - REST API with real-time WebSocket updates
  - Offline operation capability

Generated: Tue Mar  3 22:02:15 PST 2026
===============================================================================
